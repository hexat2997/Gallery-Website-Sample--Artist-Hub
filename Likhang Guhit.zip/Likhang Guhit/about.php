

<?PHP
include "includes/functions.php";
$con = db();
session_start();
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include "template/head.php";
?>
<body>
<div class="main">
<!------------------Header------------------>

<div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="index.php"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
          <li ><a href="index.php"><span>Home Page</span></a></li>
		  <li><a href="indexgallery.php"><span>Gallery</span></a></li>
		  <li   class="active" ><a href="about.php"><span>About Us</span></a></li>
          
        </ul>
      </div>
      <div class="clr"></div>
	  <div class="slider">
    <div id="coin-slider">
	<?php 
		 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
		$dispresult = mysql_query("SELECT slider_img FROM slider order by slider_id desc");
		while($dispdata = mysql_fetch_object($dispresult) ):		
		?>
	<a href="# "><img src=<?php echo $dispdata->slider_img; ?>  width="960" height="333" alt="" /></a>
	<?php
		endwhile;
		?>
	</div>

		<div class="clr"></div>
      </div>	
	 
	 
      <div class="clr"></div>
     
  </div>
    
	
	</div>

<!-------------------End of Header------->

  
  
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
		<div class="cat1">
		<h2 style="padding-left:10px; border-radius:5px">About Us</h2>
		</div>
		<hr>
			<div class="about">
			
			
			</div>
			
			
		<div class="cat1">
		<h2 style="padding-left:10px;border-radius:5px">Services</h2>
		</div>
		<hr>
			<div class="about">
			
			
			
			</div>
			
      </div>
      <div class="sidebar">
	
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Accounts</span></h2>
          <div class="clr"></div>		

		  
		  <div class="account">
		
			<div class="logform">
			<form action="" method="post">
					<?PHP
						if (isset($_POST["log"])){
						$myusername=$_POST["log_username"];
						$mypass=sha1($_POST["log_pass"]);
						$sql="select mem_id, mem_username, mem_status from members where mem_username='".$myusername."' and mem_password='".$mypass."'";
						$query=mysqli_query($con, $sql);
						$rows=mysqli_num_rows($query);
						$fetch=mysqli_fetch_array($query);
						$_SESSION["user"]=$fetch["mem_username"];
						$_SESSION["id"]=$fetch["mem_id"];
						$_SESSION["status"]=$fetch["mem_status"];
						$stat=$_SESSION["status"];
							if($rows>0 && $stat=="Member")
							{
								header("Location: home.php");
								exit;
							}

							elseif ($rows>0 && $stat=="Admin")
							{
							header("Location: admin_home.php");
							exit;
							}
							elseif ($rows>0 && $stat=="Artist")
							{
							header("Location: artist_home.php");
							exit;
							}
							else
							{
							echo "<div class='alert'> Wrong Username or Password. </div>"; /** error message **/
							}
							}
						?>
			USERNAME:<br>
				<input type="text" name="log_username" required placeholder="Username" style="margin-bottom:5px;"><br>
			PASSWORD:<br>
				<input type="password" name="log_pass" required placeholder="Password"><br>
				<input type="submit" name="log" value="Login" class="btn">
	
				</form>
				</div>
				</div>
        </div>
		
        <div class="gadget">
          <h2 class="star"><span>Sign Up Now</span></h2>
          <div class="clr"></div>
		  <?PHP
			if(isset($_POST["reg"])){
				$fname = $_POST["firstname"];
				$lname = $_POST["lastname"];
				$username = $_POST["username"];
				$pass = sha1($_POST["pass"]);
				$contact = $_POST["contact"];
				$address = $_POST["address"];
				$sql = "insert into members (mem_fname, mem_lname, mem_username, mem_password, mem_contact, mem_address, mem_status) 
				values('".$fname."', '".$lname."','".$username."', '".$pass."', '".$contact."', '".$address."','Member')";
				$res = mysqli_query($con, $sql);
				if($res)
					
				echo "<div class='success'> Successfully Registered. </div>"; /** success message **/
				
				else
				echo "<div class='alert' > Error occurred during registration!!! </div>"; /** unsuccessFUL message **/
				
			}
		?>
		<div class="regform">
		<form action="" method="post">
		  
		  
			First Name:<br>
			<input type="text" required name="firstname"><br>
			Last Name:<br>
			<input type="text" required name="lastname"><br>
			Username:<br>
			<input type="text" required name="username"><br>
			Password:<br>
			<input type="password" required name="pass"><br>
			Contact Number:<br>
			<input type="text" required name="contact"><br>
			Address:<br>
			<input type="text" required name="address"><br>
		
		
		
			<input type="submit" name="reg" value="Register" class="btn"><br>
			<br>
	
			</form>
        </div>
		</div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  
  
 <?PHP include "includes/footer.php";?>
</div>
</body>
</html>