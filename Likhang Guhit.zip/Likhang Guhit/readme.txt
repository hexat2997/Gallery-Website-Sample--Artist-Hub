960x333px images for slider view

ok na sa registration at login.,heheheh.,pati promotion.,
ok na ang slider at ang upoading ng picture sa slider.
next ay ang articles nmn