<?
				
			$query = $_GET['editbox_search']; 
		   $min_length = 3;
			 if(strlen($query) >= $min_length){ 
			  $query = htmlspecialchars($query); 
			 $query = mysql_real_escape_string($query);
			  $raw_results = mysql_query("SELECT mem_fname, mem_lname, mem_username FROM members
				WHERE (`mem_fname` LIKE '%".$query."%') OR (`mem_lname` LIKE '%".$query."%')OR (`mem_username` LIKE '%".$query."%')") or die(mysql_error());
		   if(mysql_num_rows($raw_results) > 0){ 
			  while($results = mysql_fetch_array($raw_results)){
			  
			  echo "<p><h3>".$results['mem_username']."</h3>".$results['mem_fname']."</p>";
			
			   }
				 
			}
			 else{
			 echo "No results";
			  } 
				}
								else{ 
									echo "Minimum length is ".$min_length;
								}
								
			 ?>