 <div class="gadget">
          <h2 class="star"><span>Change Password</span></h2>
          <div class="clr"></div>		

		  
		  <div class="account">
		  
        	<div class="pass">
		
			<form action="" method="post">
				<h3>NEW PASSWORD:</h3>
				<input style="width:165px" type="password" name="cha_pass" required placeholder="New Password"><br><br>
				<h3>CONFIRM PASSWORD:</h3>
				<input style="width:165px" type="password" name="cha_pass1" required placeholder="Confirm Password"><br>
				<input style="width:173px; margin-top: 18px; margin-bottom: 10px; padding-top: 4px; padding-bottom: 4px; height: 40px;" type="submit" name="change" value="Change Password" class="btn">
			<?php 

			if(isset($_POST["change"])) {

			$pass1=sha1($_POST["cha_pass"]);
			$pass2=sha1($_POST["cha_pass1"]);
			$idget=$_SESSION["id"];
			
		//	$select="select mem_password from members where mem_id=$idget";
			///$searching=mysql_query($select);
//$rowing=mysql_fetch_array($searching);
			//$select="select mem_password from members where mem_id='".$idget."'";
			//$query=mysqli_query($con, $select);
		//	$fetch=mysqli_fetch_row($query);
			if (($pass1===$pass2)||($pass2===$pass1))
			{
					
						$pass3=($pass2);
						$up_sqls="update members set mem_password='".$pass3."' where mem_id=$idget";
						$query=mysql_query($up_sqls);
						if ($query){
						echo "Record updated successfully";}
						 else {
						echo "Password does not Match or Error in Updating Password";
						}
						
			}
			else
			{
			echo "Desired Passwords does not match doesn't match";
			}
			}	
			?>
				</form>
		
		
		</div>
         
				</div>
        </div>
		<div class="clr"></div>