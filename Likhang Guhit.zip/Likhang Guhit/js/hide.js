$('document').ready(function(){

$('#cat1_show').hide();

});