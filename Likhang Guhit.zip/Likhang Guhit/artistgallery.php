

<?PHP
include "includes/functions.php";
$con = db();
session_start();
?>
<?php 
		 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				
		
		?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include "template/head.php";
?>

<script type="text/javascript">
$(document).ready(function() {
    $("a.fb_image").fancybox({
        openEffect: 'elastic',
        closeEffect: 'elastic',
        openSpeed: 600,
        closeSpeed: 600,
        helpers: {
            overlay: {
                closeClick: true,
            },
            title: {
                type: 'over'
            }
        }
    });
});
</script>








<body>
<?php 
	  $recieve=$_SESSION["id"];
	$notif_query=mysql_query("select * from message where rec_mem_id='$recieve' and mess_status='Unread'")or die(mysql_error());
	$notif_count=mysql_num_rows($notif_query);
	  ?>
<div class="main">
<!------------------Header------------------>

<div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
          <li ><a href="artist_home.php"><span>Artist Home Page</span></a></li>
		  <li class="active" ><a href="artistgallery.php"><span>Gallery</span></a></li>
		    <li ><a href="message_artist.php"><span><?php echo $notif_count;?> &nbsp;New Messages</span></a></li>
		   <li ><a href="gallery_true.php"><span>Gallery Preference</span></a></li>
		
          
        </ul>
      </div> 
	  
	  
	  <div class="clr"></div>
	  
	  <br>
	   <div class="slider">
	   
	
	
	</div>
		

		<div class="clr"></div>
      </div>
	 
      <div class="clr"></div>
     </div>
	</div>
<!-------------------End of Header------->


				


  
  
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
	  
	<h2>Gallery of Arts</h2>
		<hr>
		<span id="show_gallery">
		
		
		
		
		
		
	
	<?php
	if(isset($_GET["artistid"])){
	$artist=$_GET["artistid"];
	$getpic="select gallery.*, members.mem_fname, members.mem_lname from gallery join members on gallery.mem_id=members.mem_id where gallery.mem_id=$artist";
		$kuhalahat=mysqli_query($con,$getpic);
		}
		elseif(!isset($_GET["artistid"]))
		{
		$refer=$_SESSION["id"];
		$getpic="select gallery.*, members.mem_fname, members.mem_lname from gallery join members on gallery.mem_id=members.mem_id where gallery.mem_id=$refer";
		$kuhalahat=mysqli_query($con,$getpic);
		}
		while ($pic=mysqli_fetch_array($kuhalahat)){ 
		
	?>
	<div class="gal">
			<span> Title: <?php echo $pic['gal_title']; ?></span><br>
			<span> Medium: <?php echo $pic['gal_medium']; ?></span>
			<span><p>Artist: <?php echo $pic['mem_fname']; ?>&nbsp;<?php echo $pic['mem_lname'];?></p></span>
			<span><img src="<?php echo $pic['gal_img'];?>" width="600px"/></span><br><br>
			<hr>
		</div>
		<?php } 
		
		
		
		?>
	
	
	
	
	</span>		
	
	
	
	
			   
</div>
	

<div class="sidebar">
			  
		<div class="gadget">
		<div id="hide">		 
		<?php
		 if(isset ($_SESSION["user"])){
		// echo $_SESSION["user"];
		 $greet_user = $_SESSION["user"];
		 $user_status=$_SESSION["status"];
		echo "<h3><div class='star'>Welcome $user_status  <b>$greet_user</b></div></h3>"; 
		 }?>
		 <h3><a href='index.php'>Log out</a></h3>
		</div>
        </div>
		
	  
	  
	  
	  
	  
	  
        <div class="clr"></div>
        
		
		<div class="gadget">
          <h2 class="star"><span>Artists</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artistsql = mysql_query("SELECT mem_id, mem_lname, mem_fname, mem_status from members where mem_status='Artist'");
				
				while($artist_nav = mysql_fetch_object($artistsql) ):		
		
				?>
		
					<li><a href="artistgallery.php?artistid=<?php echo $artist_nav->mem_id;?>"><?php echo $artist_nav->mem_fname;?>&nbsp;<?php echo $artist_nav->mem_lname;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
	</div>
        </div>
		
		
		
		
		
		
		
		<div class="gadget">
          <h2 class="star"><span>Articles and Blogs	</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artsql = mysql_query("SELECT arti_id,arti_title FROM articles order by arti_id desc");
				while($arti_nav = mysql_fetch_object($artsql) ):		
		
				?>
		
					<li><a href="artist_home.php?aid=<?php echo $arti_nav->arti_id;?>"><?php echo $arti_nav->arti_title;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
				</div>
        </div>
		
		
		
		<?php include "change_password_sidebar.php"?>
		
		
		
		
    </div>  
      <div class="clr"></div>

  
	
	
 
  
  
  
  
  
  
  
  
 </div>	
  
  
  
 <?PHP include "includes/footer.php";?>
</div>
</body>
</html>