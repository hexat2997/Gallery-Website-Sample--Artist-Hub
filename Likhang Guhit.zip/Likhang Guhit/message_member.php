<?PHP
include "includes/functions.php";
$con = db();
session_start();
?>
<?php 
		 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				
		
		?>

<?php
if(!isset ($_SESSION["user"]))
{
header("Location: index.php");
} 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include "template/head.php";
?>
<body>
 <?php 
	  $recieve=$_SESSION["id"];
	$notif_query=mysql_query("select * from message where rec_mem_id='$recieve' and mess_status='Unread'")or die(mysql_error());
	$notif_count=mysql_num_rows($notif_query);
	  ?>
<div class="main">
 <div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
			<li ><a href="home.php"><span> Home Page</span></a></li>
			<li ><a href="member_gallery.php"><span>Gallery</span></a></li>
			 <li class="active" ><a href="message_member.php"><span><?php echo $notif_count ?>&nbsp; New Messages</span></a></li>
		
        
        </ul>	
      </div>
	  
	  
	
      <div class="clr"></div>
	    <div class="slider">
	   
	
<br><br>
	
		<div class="clr"></div>
      </div>	
	 	
	 
      <div class="clr"></div>
     
  </div>
	</div>
  <?php 
if (($_SESSION["status"])==="Artist")
{

header("Location:artist_home.php");
}
elseif (($_SESSION["status"])==="Admin")
{

header("Location:admin_home.php");
}


?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
 
<h2>Message</h2>
		<hr>
	 
	  <button class="btn-message"> New Message </button>
	  <script> $('document').ready(function(){
	$('.popup').hide();
	$('.btn-message').click(function(){
		$('.popup').slideDown(300);
	}, function(){
		$('.popup').slideUp(300);
	});
	
	});

	</script>
	  <?PHP
		
			if(isset($_POST["ipadala_na"])){
				$mess_username=$_POST["papadalhan"];
				$mess_body=$_POST["liham"];
				$akin_id=$_SESSION["id"];
					$getinfo = "select mem_id from members where mem_username='$mess_username'";
					$query = mysql_query($getinfo);
					$row = mysql_fetch_array($query);
					if ($row)
					{
					$nakaw1 = $row['mem_id'];
				$messsql = "insert into message (rec_mem_id, send_mem_id, mess_content,mess_status) 
				values('$nakaw1', '$akin_id', '$mess_body','Unread')";
				$res = mysqli_query($con, $messsql);
				if($res)
				{
				echo "Message Sent";
				}
				}
				else
				{
				echo "<p style='font-size:17px; color:black;'>Username '$mess_username' doesnt exist</p>";
				}
				
			}
		
		
				?>	
	  		<div style="border-style:solid;background-color:white;"class="popup">
		<div class="inside">
		
		<form action="" method="post">
		Username:<br>
		<input type="text" name="papadalhan" placeholder="username" required><br><br>
		Message:<br>
		<textarea name="liham" rows="6" cols="80"></textarea><br><br>
		<div class="btnsend"><input type="submit" name="ipadala_na" value="SEND	"></div>
		
		</form>
		</div>
		</div>
	  <table align="left"  class="t_mess">
							<thead>
									<tr><th></th>
									  <th width="60px">Sender</th><br>
									  <th>Content</th>
									  <th>Date</th> <th></th> <th></th>
									  <th> </th>
									</tr>
								  </thead>
		<?php 
		$session_id=$_SESSION["id"];
		$result = mysql_query("select message.*,members.mem_username from message join members on message.send_mem_id=members.mem_id where rec_mem_id=$session_id order by mess_id desc" );
		while($datamess = mysql_fetch_object($result) ):
		?>
	<tbody>
		<tr><td><?php $var=$datamess->mess_id ;
	$sql_check = mysql_query("Select mess_status from message where mess_id=$var ");
	$checking=mysql_fetch_object($sql_check);
	$checkingresult=$checking->mess_status;
	if($checkingresult=="Unread")
		{	
		echo "<img src='images/close.jpg' width='20' height='20'>";
		}
		else
		echo "<img src='images/open.jpg' width='20' height='20'>";
		?></td>	
		<td><?php echo $datamess->mem_username ?></td>
		<td><?php echo $datamess->mess_content?></td>
		<td><?php echo $datamess->mess_date?></td>
		<td><a href="message_reply_member.php?repz=<?php echo $datamess->mess_id?>">View</td><a>
		<td><a href="delete_messagebyID.php?bura_mensahe=<?php echo $datamess->mess_id?>"> Delete Message </a></td>
		</tr>
	
	
			
		<?Php
		endwhile;
		?>
		</tbody>
			</table>
	<!----------------reply message dialog-------------->
	
	<!----
	<script type="text/javascript">
    $(function () {
        $(".reply").dialog({
            modal: true,
            autoOpen: false,
            title: "Message",
            width: 530,
            height: 350
        });
        $(".btn-reply").click(function () {
            $('.reply').dialog('open');
        });
    });
</script>
-->
	
		
		
		
		
		
		
		
		
		
		
		<!---
		
		
<script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>

		
	 <script type="text/javascript">
    $(function () {
        $(".popup").dialog({
            modal: true,
            autoOpen: false,
            title: "Message",
            width: 530,
            height: 350
        });
        $(".btn-message").click(function () {
            $('.popup').dialog('open');
        });
    });
</script>-->
		</div>
      <div class="sidebar">
        
		<div class="gadget">
		<div id="hide">		 
		<?php
		 if(isset ($_SESSION["user"])){
		// echo $_SESSION["user"];
		 $greet_user = $_SESSION["user"];
		 $user_status=$_SESSION["status"];
		echo "<h3><div class='star'>Welcome $user_status  <b>$greet_user</b></div></h3>"; 
		 }?>
		 <h3><a href='index.php'>Log out</a></h3>
		</div>
        </div>
		
		
		
        <div class="clr"></div>
     
		 <div class="gadget">
          <h2 class="star"><span>Articles and Blogs	</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artsql = mysql_query("SELECT arti_id,arti_title FROM articles order by arti_id desc");
				while($arti_nav = mysql_fetch_object($artsql) ):		
		
				?>
		
					<li><a href="home.php?aid=<?php echo $arti_nav->arti_id;?>"><?php echo $arti_nav->arti_title;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
				</div>
        </div>
		
		
		<div class="gadget">
          <h2 class="star"><span>Artists</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artistsql = mysql_query("SELECT mem_id, mem_lname, mem_fname, mem_status from members where mem_status='Artist'");
				
				while($artist_nav = mysql_fetch_object($artistsql) ):		
		
				?>
		
					<li><a href="member_gallery.php?artistid=<?php echo $artist_nav->mem_id;?>"><?php echo $artist_nav->mem_fname;?>&nbsp;<?php echo $artist_nav->mem_lname;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
	</div>
        </div>
		<?php include "change_password_sidebar.php"?>
		
      </div>
      <div class="clr"></div>
	  
    </div>
  </div>
  <?php
  include "includes/footer.php"; 
  ?>
</div>
</body>
</html>