<?PHP
include "includes/functions.php";
$con = db();
session_start();
?>
  <?php 
		 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
	?>
<?php
if(!isset ($_SESSION["user"]))
{
header("Location: index.php");
} 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include "template/head.php";
?>
 
<head>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript"></script>
</head>
<body>
 <?php 
	  $recieve=$_SESSION["id"];
	$notif_query=mysql_query("select * from message where rec_mem_id='$recieve' and mess_status='Unread'")or die(mysql_error());
	$notif_count=mysql_num_rows($notif_query);
	  ?>
<div class="main">
<!-------------HEAder-------->
<div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
			<li><a href="admin_home.php"><span>Admin Home Page</span></a></li>
			<li><a href="admin_gallery.php"><span>Gallery</span></a></li>
			<li><a href="message.php"><span><?php echo $notif_count;?> New Messages</span></a></li>
			<li class="active"><a  href="admin_pref.php"><span>Admin Preferences</span></a>
			</li>
			</ul>	
      </div>
	  
	  
	  
	  
	  <div class="clr"></div>	  
	  <br>
	   <div class="slider">
	 
	</div>
		<div class="clr"></div>
      </div>
	 
      <div class="clr"></div>
     </div>
	</div>
	
	
	
	
	
	
	
	
	
	
 <!--------------end of header---->
 <?php 
 

 
if ((($_SESSION["status"])==="Artist") && (($_SESSION["user"])!=="troy"))
{

header("Location:artist_home.php");
}
elseif (($_SESSION["status"])==="Member")
{

header("Location:home.php");
}

?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
	  
	  
	  
	  
	<h2>Admin Preference</h2>
		<hr>
	  
	  	<div class="cat2">
	<h2 style='padding-left:10px; border-radius: 5px'><span2>Change/Add Articles</span2></h2> 
	</div>
	<script> $('document').ready(function(){
//	$('#cat2_show').hide();
	
	$('.cat2').toggle(function(){
		$('#cat2_show').slideDown(300),$('.pass').slideUp(300),$('.imageslider').slideUp(300);
	}, function(){
		$('#cat2_show').slideUp(300);
	});
	
	});

	</script>
	
	<div class="clr"></div>
	<div id="cat2_show">
	<!--------------add articles---------------->
	 <?php 
	 $target_dir = "uploads/";
	if(isset($_POST["arti_post"])) {
	$add_arti_title=$_POST["title"];
	$add_arti_parag=$_POST["parag"];
	$add_id=$_SESSION["id"];
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if(($check !== false) && (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file))){
	echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " and Articles has been uploaded.";
	$insert_sql="insert into articles (arti_title, arti_imagepath, arti_parag, mem_id) values ('$add_arti_title','$target_file', '$add_arti_parag','$add_id')";
	$res = mysqli_query($con, $insert_sql);	
	   } 
	else
	{

	echo "Error in Uploading our Image"	;
	}
	}	
	?>
	<div class="addarticles">
	<form name="add_articles" action="" method="post" enctype="multipart/form-data">
	<input class="arttitle"type="text" name="title"><br>
	 <div class="artimg"><input type="file" name="fileToUpload" id="fileToUpload"><br></div>
	<textarea class="artbody" name="parag"></textarea><br>
	<input class="postarti" type="submit" name="arti_post" value="Post"><br>
	</form>
	</div>
	<div id="display_art">
									<table class="table table-bordered">
								  <thead>
									
									  <h2 class="tit" width="60px">List of Articles</h2>
									
									
								  </thead>
									<tbody>
								  <?php 
								 	$result = mysql_query("SELECT * FROM articles order by arti_id desc");
									while($data = mysql_fetch_object($result) ):		
								  ?>
								  <div class="articlelist">
									<tr>	
									
									  <td><h4><?php echo $data->arti_title ?></h4><hr></td>
									  
									   <td>
										<a href="deleteByartiId.php?id=<?php echo $data->arti_id ?>">
											<button class="delarti"> Delete </button>
										</a>
									  </td>
									</tr>
									</div>
								  <?php
									endwhile;
								  ?>
								  </tbody>
							</table>
	</div>
	</div>
		
	<br>
	
		<div class="cat1">
		<h2 style="padding-left:10px; border-radius: 5px;"><span4>Change Password</span4></h2>
		</div>
		
		<script> $('document').ready(function(){
	$('.pass').hide();
	
	$('.cat1').toggle(function(){
		$('.pass').slideDown(300),$('#cat2_show').slideUp(300),$('.imageslider').slideUp(300);
	}, function(){
		$('.pass').slideUp(300);
	});
	
	});
	</script>


	<br>
	<br>


	
	
			<div class="pass">
		
			<form action="" method="post">
				<h3>NEW PASSWORD:</h3>
				<input style="width:165px" type="password" name="cha_pass" required placeholder="New Password"><br><br>
				<h3>CONFIRM PASSWORD:</h3>
				<input style="width:165px" type="password" name="cha_pass1" required placeholder="Confirm Password"><br>
				<input style="width:173px; margin-top: 18px; margin-bottom: 10px; padding-top: 4px; padding-bottom: 4px; height: 40px;" type="submit" name="change" value="Change Password" class="btn">
			<?php 

			if(isset($_POST["change"])) {

			$pass1=sha1($_POST["cha_pass"]);
			$pass2=sha1($_POST["cha_pass1"]);
			$idget=$_SESSION["id"];
			
		//	$select="select mem_password from members where mem_id=$idget";
			///$searching=mysql_query($select);
//$rowing=mysql_fetch_array($searching);
			//$select="select mem_password from members where mem_id='".$idget."'";
			//$query=mysqli_query($con, $select);
		//	$fetch=mysqli_fetch_row($query);
			if (($pass1===$pass2)||($pass2===$pass1))
			{
					
						$pass3=($pass2);
						$up_sqls="update members set mem_password='".$pass3."' where mem_id=$idget";
						$query=mysql_query($up_sqls);
						if ($query){
						echo "Record updated successfully";}
						 else {
						echo "Password does not Match or Error in Updating Password";
						}
						
			}
			else
			{
			echo "Desired Passwords does not match doesn't match";
			}
			}	
			?>
				</form>
		
		
		</div>
		
		
		
		<br>
		<br>
		
		
	
		
		
		
		<!--------------start of cat 1 --------------->
		
	<div class="cat1">
	<h2 style='padding-left:10px; border-radius: 5px'><span1>Change/Add Slider Images</span1></h2>

	</div>
		 <div class="clr"></div>
	
	
	<script> $('document').ready(function(){
	$('.imageslider').hide();
	
	$('span1').toggle(function(){
		$('.imageslider').slideDown(300),$('.pass').slideUp(300),$('#cat2_show').slideUp(300);
	}, function(){
		$('.imageslider').slideUp(300);
	});
	
	});

	</script>
	
	
	
	<!--------------UPLOAD PHP SLIDER----------------->
	
		 <?php $target_dir = "uploads/";
	if(isset($_POST["OK"])) {
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if(($check !== false) && (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file))){

   echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
	$insert_sql="insert into slider(slider_img) values ('".$target_file."')";
	$res = mysqli_query($con, $insert_sql);

    } 
	else
	{

	echo "Error in Uploading our Image";
	}
	}	
	

	?>
	<?phpif (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;?>
	
	<!-----------END OF UPLOAD PHP SLIDER----------->
	<div class="imageslider">
	<div class="Addslider">
	<form action="" method="post" enctype="multipart/form-data">
    <h4>Select image to upload:</h4>
    <input  type="file" name="fileToUpload" id="fileToUpload"><br>
    <input style="width:173px; margin-top: 18px; padding-top: 4px; padding-bottom: 4px; height: 40px;" type="submit" value="Add Image" name="OK">
	</form>
	</div>
						<div class="sliderimg">
							
							<table class="sliderdiv">
								  <thead>
									<tr>
									  
									  <h2 class="tit" width="60px"> Slider Images</h2>
									  <th> </th>
									</tr>
								  </thead>
								  <tbody>
								  <?php 
								 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
									$result = mysql_query("SELECT * FROM slider order by slider_id desc");
									while($data = mysql_fetch_object($result) ):		
								  ?>
									<tr>	
									   <td><img src ="	<?php echo $data->slider_img ?>" width="200" alt="slider images"></img></td>
									 
									  <td>
										<a href="deleteById.php?id=<?php echo $data->slider_id ?>">
											<button class="delarti"> Delete </button>
										</a>
									  </td>
									</tr>
									
								  <?php
									endwhile;
								  ?>
								  </tbody>
							</table>
					</div>	
					</div>
	
	 <div class="clr"></div>	
	
	
	<!--------------End of cat 1 --------------->
		<!--------------start of cat2--------------->
	
	<!--------------End of cat 2 ---------------->
	 <div class="clr">
	 </div>	
	 <br>
	
	 <div class="clr"></div>	
	

       
	 
       
	</div>
      <div class="sidebar">
	  
	  <div class="gadget">
		<div id="hide">		 
		<?php
		 if(isset ($_SESSION["user"])){
		// echo $_SESSION["user"];
		 $greet_user = $_SESSION["user"];
		 $user_status=$_SESSION["status"];
		echo "<h3><div class='star'>Welcome $user_status  <b>$greet_user</b></div></h3>"; 
		 }?>
		 <h3><a href='index.php'>Log out</a></h3>
		</div>
        </div>
		
	 		
		
		
        <div class="clr"></div>
        <div class="gadget">
          <h2 class="star"><span>Promote/Demote User</span></h2>
          <div class="clr"></div>		

								  
						<div class="account">
						
						
						
						<?PHP
						if (isset($_POST["Promote"])){
						$user_promote=$_POST["user_promote"];
						$user_status=$_POST["level_status"];
						$troy=$_SESSION['user'];
				if($troy!=='troy')
				{
					if (($user_promote==='troy')||($user_promote==='admin')){
						echo "You cannot change his position! He owns this website.";
						}
					else{
						$sql="update members set mem_status='".$user_status."' where mem_username='".$user_promote."'";
							$query=mysqli_query($con, $sql);
							if(($con->query($sql) === TRUE)){
						  echo "Record updated successfully";
						} else {
							echo "Error updating record: ";
						}
						}
						}
						elseif($troy==='troy')
						{
						if ($user_promote==='admin'){
						echo "You cannot change his position! He owns this website.";
						}
						else{
						$sql="update members set mem_status='".$user_status."' where mem_username='".$user_promote."'";
							$query=mysqli_query($con, $sql);
							if(($con->query($sql) === TRUE)){
						  echo "Record updated successfully";
						} else {
							echo "Error updating record: ";
						}
						}
						
						
						}}
							?>
							
							
							
							
          <form action="" method="post">
			USERNAME:<br>
				<input type="text" name="user_promote"><br>
			LEVEL STATUS:<br>
				<input type="radio" name="level_status" value="Admin">Admin<br>
				<input type="radio" name="level_status" value="Artist">Artist<br>
					<input type="radio" name="level_status" value="Member" checked="checked">Member<br>
				<input type="submit" name="Promote" value="promote"><br>
		
				</form>
				</div>
        </div>
		
      </div>
      <div class="clr"></div>
    </div>
  </div>
  
  
  
  
  
  
 <?PHP include "includes/footer.php";?>
</div>
</body>
</html>