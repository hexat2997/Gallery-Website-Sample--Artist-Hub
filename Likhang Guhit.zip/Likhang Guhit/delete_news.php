<?php 
include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 

$id = $_GET['BURA_BALITA']; /** get the student ID ***/

mysql_query("DELETE FROM articles where arti_id = '$id'"); /** execute the sql delete code **/

header("Location: admin_pref.php"); /** redirect to delete.php **/

?>
