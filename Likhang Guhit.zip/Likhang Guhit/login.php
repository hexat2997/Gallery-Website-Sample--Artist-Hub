<?PHP
include "includes/functions.php";
$con=db();
?>

<?PHP
if (isset($_POST["log"])){
$username1=$_POST["username"];
$pass1=sha1($_POST["pass"]);
$sql1="select username from members where username='".$username."' and pass='".$pass."'";
$query1=mysqli_query($con, $sql1);
$rows1=mysqli_num_rows($query1);
$fetch1=mysqli_fetch_array($query1);
$user=$fetch1["username"];
if($rows1>0)
{
header("Location: blog.html");
exit;
}
else
{echo "<div class='alert'> Wrong Username or Password. </div>"; /** error message **/
}
}
?>