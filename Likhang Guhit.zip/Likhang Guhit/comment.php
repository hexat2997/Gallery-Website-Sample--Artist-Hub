<?PHP
include "includes/functions.php";
$con = db();
session_start();
?>
<?PHP
		
		
			if(isset($_POST["comment"])){
				$arti_id_comment=$_GET["aid"];
				$mem_id_comment=$_SESSION["id"];
				$comment_body=$_POST["comment_body"];
				$sql = "insert into tbl_comment ( mem_id, comment_body) 
				values('$arti_id_comment','$mem_id_comment','$comment_body')";
				$res = mysqli_query($con, $sql);
				if($res)
					
				header("location:admin_home.php");	
				else
				echo "<div class='alert' > Error occurred during registration!!! </div>"; /** unsuccessFUL message **/
			
			}
			
		
?>