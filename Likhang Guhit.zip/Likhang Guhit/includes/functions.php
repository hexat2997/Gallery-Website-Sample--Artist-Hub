<?PHP
include "includes/configuration.php";

//----Connection to database--///
function db()
{
$con=mysqli_connect (DB_SERVER, DB_USER, DB_PASS, DB_DATABASE);
IF(!$con) return false;
return $con;
}
//----Connection to database--///

//----log out in session--///


//----log out in session--///

function test_input($validate) {
  $validate = trim($validate);
  $validate = stripslashes($validate);
  $validate = htmlspecialchars($validate);
  return $validate;
}





?>
