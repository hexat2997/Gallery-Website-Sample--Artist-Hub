<div class="footer">
    <div class="footer_resize">
      <p class="lf">Copyright &copy; <a href="#	">Likhang Guhit Art Gallery</a>. All Rights Reserved 2016</p>
      <p class="rf">Developed by <a target="_blank" href="https://www.facebook.com/emersonsonsonsonson">Caisip, Emerson </a>& <a target="_blank" href="https://www.facebook.com/troejan23">De Asis,Troy Jordan</a></p>
      <div style="clear:both;"></div>
    </div>
  </div>