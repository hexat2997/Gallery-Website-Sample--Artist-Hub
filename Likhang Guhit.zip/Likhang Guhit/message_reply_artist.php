<?PHP
include "includes/functions.php";
$con = db();
session_start();
?>
<?php 
		 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				
		
		?>

<?php
if(!isset ($_SESSION["user"]))
{
header("Location: index.php");
} 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include "template/head.php";
?>
<body>
 <?php 
	  $recieve=$_SESSION["id"];
	$notif_query=mysql_query("select * from message where rec_mem_id='$recieve' and mess_status='Unread'")or die(mysql_error());
	$notif_count=mysql_num_rows($notif_query);
	  ?>
<div class="main">
 <div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
			<li ><a href="artist_home.php"><span>Artist Home Page</span></a></li>
			<li><a href="artistgallery.php"><span>Gallery</span></a></li>
			<li class="active"><a href="message_artist.php"><span><?php echo $notif_count;?> &nbsp;New Messages</span></a></li>
	
        </ul>	
      </div>
      <div class="clr"></div>
	  
	  
	  
	  
	  <br>
	   <div class="slider">
	   
	
	
	</div>
	
	
	
	
	

		<div class="clr"></div>
      </div>	
	 
      <div class="clr"></div>
     
  </div>
	</div>
  <?php 
if (($_SESSION["status"])==="Admin")
{

header("Location:artist_home.php");
}
elseif (($_SESSION["status"])==="Member")
{

header("Location:home.php");
}


?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
	  
	<h2>Message</h2>
		<hr>
	
	<?PHP
	$reply_username=$_GET["repz"]; 
	$selecting_sql="select message.*,members.mem_username from message join members on message.send_mem_id =members.mem_id where mess_id=$reply_username";
	$query21 = mysql_query($selecting_sql);
	$row21 = mysql_fetch_array($query21);
	$getusename=$row21['mem_username'];
	$getmessage=$row21['mess_content'];
			if(isset($_POST["oknachar"])){
				$mess_username=$getusename;
				$mess_body=$_POST["replymessage"];
				$akin_id=$_SESSION["id"];
				$getinfo = "select mem_id from members where mem_username='$getusename'";
				$query = mysql_query($getinfo);
				$row = mysql_fetch_array($query);
				$nakaw1 = $row['mem_id'];
				$messsql = "insert into message (rec_mem_id, send_mem_id, mess_content,mess_status) 
				values('$nakaw1', '$akin_id', '$mess_body','Unread')";
				$res = mysqli_query($con, $messsql);
				if($res)
				{
				
				echo "<p style='font-size:17px; color:black;'>Message Sent</p>";
				}
				
			}
		
	
				?>
<?php 
if(isset ($_GET["repz"])){

$upsmess="update message set mess_status='Read' where mess_id=$reply_username";
$okupdate=mysql_query($upsmess);
}
else
echo 'error update';
?>


	 
	<!----------------reply message dialog-------------->
	
	
	<div style="border-style:solid;background-color:white;"class="reply">
		<div class="inside">
	
		<form action="" method="post">
		Username:<br>
		<input type="text" name="1" value="<?php echo $getusename	 ?>"  required><br>
		Message:<br>
		<p style="font-size:17px; color:black;"><b><?php echo $getmessage?></b></p><br><br>
	
		<div class="labasmess1"><input type="submit" name="labasmess" value="Reply"></div>
		
		</form>
		</div>
		</div>
		
	<div style="border-style:solid;background-color:white;"class="reply2">
		<div class="inside">
	
		<form action="" method="post">
		Message:<br>
		<textarea name="replymessage" rows="6" cols="60" placeholder="Type your message here."></textarea><br>
		<input type="submit" name="oknachar" value="Send">
		
		</form>
		</div>
		</div>
	
	 
	
	<!--
	<script type="text/javascript">
    $(function () {
        $(".reply").dialog({
            modal: true,
            autoOpen: false,
            title: "Message",
            width: 530,
            height: 350
        });
        $(".btn-reply").click(function () {
            $('.reply').dialog('open');
        });
    });
</script>

	-->
		
		
		
		
		
		
		
		
		
	
		
		
		
		
	
		
<!--------------new message dialog--------->
		
		</div>
      <div class="sidebar">
        
		<div class="gadget">
		<div id="hide">		 
		<?php
		 if(isset ($_SESSION["user"])){
		// echo $_SESSION["user"];
		 $greet_user = $_SESSION["user"];
		 $user_status=$_SESSION["status"];
		echo "<h3><div class='star'>Welcome $user_status  <b>$greet_user</b></div></h3>"; 
		 }?>
		 <h3><a href='index.php'>Log out</a></h3>
		</div>
        </div>
		
		
	
	
        <div class="clr"></div>
     
		 <div class="gadget">
          <h2 class="star"><span>Articles and Blogs	</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artsql = mysql_query("SELECT arti_id,arti_title FROM articles order by arti_id desc");
				while($arti_nav = mysql_fetch_object($artsql) ):		
		
				?>
		
					<li><a href="admin_home.php?aid=<?php echo $arti_nav->arti_id;?>"><?php echo $arti_nav->arti_title;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
				</div>
        </div>
		
		
		<div class="gadget">
          <h2 class="star"><span>Artists</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artistsql = mysql_query("SELECT mem_id, mem_lname, mem_fname, mem_status from members where mem_status='Artist'");
				
				while($artist_nav = mysql_fetch_object($artistsql) ):		
		
				?>
		
					<li><a href="admin_gallery.php?artistid=<?php echo $artist_nav->mem_id;?>"><?php echo $artist_nav->mem_fname;?>&nbsp;<?php echo $artist_nav->mem_lname;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
	</div>
        </div>
		<?php include "change_password_sidebar.php"?>
		
      </div>
      <div class="clr"></div>
	  
    </div>
  </div>

  
 <?PHP include "includes/footer.php";?>
</div>
</body>
</html>