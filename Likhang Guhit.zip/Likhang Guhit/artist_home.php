	<?PHP
include "includes/functions.php";
$con = db();
session_start();	
 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
?>
<?php
if(!isset ($_SESSION["user"]))
{
header("Location: index.php");
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include "template/head.php";
?>
<body>
<?php 
	  $recieve=$_SESSION["id"];
	$notif_query=mysql_query("select * from message where rec_mem_id='$recieve' and mess_status='Unread'")or die(mysql_error());
	$notif_count=mysql_num_rows($notif_query);
	  ?>
<div class="main">
  <!-----------Header---------->
  <div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>

			
          <li class="active" ><a href="artist_home.php"><span>Artist Home Page</span></a></li>
		  <li ><a href="artistgallery.php"><span>Gallery</span></a></li>
		    <li ><a href="message_artist.php"><span><?php echo $notif_count;?> &nbsp;New Messages</span></a></li>
		   <li ><a href="gallery_true.php"><span>Gallery Preference</span></a></li>
		
          

		</ul>
      </div>
      <div class="clr"></div>
	   <div class="slider">
        <div id="coin-slider">
	<?php 
	
		$dispresult = mysql_query("SELECT slider_img FROM slider order by slider_id desc");
		while($dispdata = mysql_fetch_object($dispresult) ):		
		?>
	<a href="# "><img src=<?php echo $dispdata->slider_img; ?>  width="960" height="333" alt="" /></a>
	<?php
		endwhile;
		?>
	</div>	

		<div class="clr"></div>
      </div>
	 
      <div class="clr"></div>
     
  </div>
    
	
	</div>
  
  
  
  <!-------------end of header-------->
  <?php 
if (($_SESSION["status"])==="Member")
{

header("Location:home.php");
}
elseif (($_SESSION["status"])==="Admin")
{

header("Location:artist_home.php");
}


?>
  
  
  
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
	
	<?php

if(isset($_GET["aid"])){
$ref = ($_GET["aid"]);
		$sql2 = "SELECT articles.*,members.mem_username FROM articles inner join members on articles.mem_id=members.mem_id where arti_id=$ref";
		//$count_sql="select * from bl_comments where arti_id=$ref";
		//$count=mysqli_num_rows($count_sql);
		
	$comment_query=mysql_query("select * from tbl_comment where arti_id='$ref'")or die(mysql_error());
	$count=mysql_num_rows($comment_query);

		
		
			$query2 = mysqli_query($con, $sql2);
		
			if($fetch = mysqli_fetch_array($query2))
			{
			
					
					$title = $fetch["arti_title"];
					$arti_img = $fetch["arti_imagepath"];
					$parag = $fetch["arti_parag"];
					$date = $fetch["arti_date"];
					$mem_id_arti = $fetch["mem_username"];
					
			
			}
			
			
			
			}
			elseif(!isset($_GET["aid"])){
			$sql2 = "SELECT articles.*,members.mem_username FROM articles inner join members on articles.mem_id=members.mem_id order by arti_id desc limit 1";
		$query2 = mysqli_query($con, $sql2);
		$sql69="select arti_id from articles order by arti_id desc limit 1";
		
		
			if($fetch = mysqli_fetch_array($query2))
			{
			
					$ito_na=$fetch["arti_id"];
					$title = $fetch["arti_title"];
					$arti_img = $fetch["arti_imagepath"];
					$parag = $fetch["arti_parag"];
					$date = $fetch["arti_date"];
					$mem_id_arti = $fetch["mem_username"];
					
			
			}
			$comment_query=mysql_query("select * from tbl_comment where arti_id='$ito_na'")or die(mysql_error());
		$count=mysql_num_rows($comment_query);
			
			}


	?>
			


        <div class="article">
          <h2><span><?php echo $title;?></span></h2>
		  <!---------------->
			
			
		  <!--------------->
          <p class="infopost">Posted on <span class="date"><?php echo $date;?></span> by <a href="#"><?php echo $mem_id_arti;?></a> &nbsp;&nbsp;|&nbsp;&nbsp; Filed under <a href="#">templates</a>, <a href="#">internet</a> <a href="#" class="com"><span><?PHP echo $count; ?></span> Comments</a></p>
          <div class="clr"></div>
          <div class="img"><img src="<?php echo $arti_img;?>" width="177" height="213" alt="" class="fl" /></div>
		  
		  
		  
		  
		  
          <div class="post_content">
            <p style="text-align:justify;text-indent:50px;"><?php echo $parag;?></p>
            <div class="view">
            <p class="spec"><a  href="#" class="rm">View Comments &raquo;</a></p>
			
			</div>
			
          </div>
          <div class="clr"></div>
		  
        </div>	
			<script> $('document').ready(function(){
			$('#comment_table').hide();
	
			$('.rm').toggle(function(){
				$('#comment_table').show(),$('.rm').text('Hide Comments');
			}, function(){
				$('#comment_table').hide(),$('.rm').text('View Comments');
			});
			
			});

	</script>
			
			
			
			
			
		<div id="comment_table"><h3>Comments: </h3>
		<?php 
		if(isset( $_GET["aid"])){
		$ref = ($_GET["aid"]);
		$result = mysql_query("select members.mem_fname, members.mem_lname, tbl_comment.comment_body, tbl_comment.comment_date from members join tbl_comment on members.mem_id=tbl_comment.mem_id where tbl_comment.arti_id=$ref order by tbl_comment.comment_id");
		}
		elseif(!isset( $_GET["aid"])){
		$result = mysql_query("select members.mem_fname, members.mem_lname, tbl_comment.comment_body, tbl_comment.comment_date from members join tbl_comment on members.mem_id=tbl_comment.mem_id where arti_id='$ito_na' order by tbl_comment.comment_id");
		}
		while($data = mysql_fetch_object($result) ):
		
		?><div class="viewcom">
		<table align="left">
		<tr>
		<td><b><?php echo $data->mem_fname ?></b></td>
		<td><i><?php echo $data->comment_body?></i></td><br>
		<td><?php echo $data->comment_date?></td><br>	
		</tr>
		</table>
		</div>
		<?Php
		endwhile;
		?>
		
		
		
		</div>
		<br>
		
	<br>
       <div class="comments">
	   <div id="commentload">
	 	<?PHP
		if(isset($_GET["aid"])){
			if(isset($_POST["comment"])){
				$arti_id_comment=$_GET["aid"];
				$mem_id_comment=$_SESSION["id"];
				$comment_body=$_POST["comment_body"];
				$sql = "insert into tbl_comment ( arti_id,	mem_id, comment_body) 
				values('$arti_id_comment','$mem_id_comment','$comment_body')";
				$res = mysqli_query($con, $sql);
				header("location:admin_home.php?aid=$ref");
			}}
		elseif(!isset($_GET["aid"])){
			if(isset($_POST["comment"])){
				
				$mem_id_comment=$_SESSION["id"];
				$comment_body=$_POST["comment_body"];
				$sql = "insert into tbl_comment ( arti_id,	mem_id, comment_body) 
				values('$ito_na','$mem_id_comment','$comment_body')";
				$res = mysqli_query($con, $sql);
				header("location:admin_home.php");
			}}
		
		
				?>
			</div>
			<br>
			<div class="commentpanel">
		<form action="" method="post">
		
		<textarea required placeholder="Type your comment here" name="comment_body" rows="5" cols="40"></textarea><br>
		<input type="submit" name="comment" value="Post Comment" class="btn">
		</form>
	
		</div></div>
       
	 
      </div>
<div class="sidebar">
			  
			  <div class="gadget">
		<div id="hide">		 
		<?php
		 if(isset ($_SESSION["user"])){
		// echo $_SESSION["user"];
		 $greet_user = $_SESSION["user"];
		 $user_status=$_SESSION["status"];
		echo "<h3><div class='star'>Welcome $user_status  <b>$greet_user</b></div></h3>"; 
		 }?>
		 <h3><a href='index.php'>Log out</a></h3>
		</div>
        </div>
		
	  
	  
	  
	  
	  
	  
        <div class="clr"></div>
        
		
		<div class="gadget">
          <h2 class="star"><span>Artists</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artistsql = mysql_query("SELECT mem_id, mem_lname, mem_fname, mem_status from members where mem_status='Artist'");
				
				while($artist_nav = mysql_fetch_object($artistsql) ):		
		
				?>
		
					<li><a href="artistgallery.php?artistid=<?php echo $artist_nav->mem_id;?>"><?php echo $artist_nav->mem_fname;?>&nbsp;<?php echo $artist_nav->mem_lname;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
	</div>
        </div>
		
		
		
		
		
		
		
		<div class="gadget">
          <h2 class="star"><span>Articles and Blogs	</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artsql = mysql_query("SELECT arti_id,arti_title FROM articles order by arti_id desc");
				while($arti_nav = mysql_fetch_object($artsql) ):		
		
				?>
		
					<li><a href="artist_home.php?aid=<?php echo $arti_nav->arti_id;?>"><?php echo $arti_nav->arti_title;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
				</div>
        </div>
		
		
		<?php include "change_password_sidebar.php"?>
		
		
		
		
		
    </div>  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
      <div class="clr"></div>
    </div></div>
	
	
  
  
 <?PHP include "includes/footer.php";?>
</div>
</body>
</html>