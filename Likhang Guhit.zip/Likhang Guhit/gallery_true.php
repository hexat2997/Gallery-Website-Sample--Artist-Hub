<?PHP
include "includes/functions.php";
$con = db();
session_start();
?>
<?php 
		 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
		
		?>


<?php
if(!isset ($_SESSION["user"]))
{
header("Location: index.php");
} 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
include "template/head.php";
?>
<body>
 <?php 
	  $recieve=$_SESSION["id"];
	$notif_query=mysql_query("select * from message where rec_mem_id='$recieve' and mess_status='Unread'")or die(mysql_error());
	$notif_count=mysql_num_rows($notif_query);
	  ?>
<div class="main">
 <div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
			<li ><a href="artist_home.php"><span>Artist Home Page</span></a></li>
			<li ><a href="artistgallery.php"><span>Gallery</span></a></li>
		    <li ><a href="message_artist.php"><span><?php echo $notif_count;?> &nbsp;New Messages</span></a></li>
			<li class="active" ><a href="gallery_true.php"><span>Gallery Preferences</span></a></li>

        </ul>	
      </div>
      <div class="clr"></div>
	   <br><br>
	
		<div class="clr"></div>
      </div>	
      <div class="clr"></div>
     
  </div>
	</div>
  
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
	<h2>Gallery Preferences</h2>
		<hr>
		
		
	
	<?php 
	 $target_dir = "gallery/";
	if(isset($_POST["art_post"])) {
	$add_gal_title=$_POST["title"];
	$add_gal_medium=$_POST["materials"];
	$add_id=$_SESSION["id"];
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if(($check !== false) && (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file))){
	echo "<h3> New Image Added</h3>";
	$insert_sql="insert into gallery (gal_title, gal_medium, gal_img, mem_id) values ('$add_gal_title','$add_gal_medium','$target_file','$add_id')";
	$res = mysqli_query($con, $insert_sql);
    } 
	else
	{

	echo "Error in Uploading our Image";
	}
	}	
	?>
	<div class="add" style="width: 700px">

	<div class="page-header">
    	<h3>Add new image to Gallery. </h3>
    </div>
    
<div class="addimage">
	<form name="add_image" action="" method="post" enctype="multipart/form-data">
	Title:
	<input style="margin-left: 26px" type="text" name="title" required placeholder="Art Title"><br>
	Medium:
	<input style="margin-left: 5px"type="text"name="materials" required placeholder="Medium Used"></input><br>
	Image to Upload:<br>
	<input type="file" name="fileToUpload" id="fileToUpload" required><br>
	
	
	<button class="btn" style=" width: 200px"type="submit" name="art_post" >
         &nbsp; Post to Gallery
	</form>
</div>


</div>
<hr>




<div id="show_gallery">
							<?php 
							$idkoto=$_SESSION["id"];
								 include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
									$result = mysql_query("SELECT gallery.*, members.mem_fname, members.mem_lname FROM gallery join members on gallery.mem_id=members.mem_id where gallery.mem_id=$idkoto order by gal_id desc");
									while($data = mysql_fetch_object($result) ):		
								  ?>
								
									 
									<p class="page-header">Title: <?php echo $data->gal_title ?>&nbsp;<?php echo $data->gal_medium ?></p>
									<p class="page-header">Artist: <?php echo $data->mem_fname ?>&nbsp;<?php echo $data->mem_lname ?></p>
									<img src="<?php echo $data->gal_img ?>" class="img-rounded" width="500px"/>
									<a href="delete_art.php?art=<?php echo $data->gal_id ?>">
									<br>
											<button class="btn"> Delete </button>
										</a><hr>
									<p class="page-header"></p>
									
									
								
									  
									
								  <?php
									endwhile;
								  ?>
	
	
	</div>		
	
	
      </div>
      <div class="sidebar">
        
		<div class="gadget">
		<div id="hide">		 
		<?php
		 if(isset ($_SESSION["user"])){
		// echo $_SESSION["user"];
		 $greet_user = $_SESSION["user"];
		 $user_status=$_SESSION["status"];
		echo "<h3><div class='star'>Welcome $user_status  <b>$greet_user</b></div></h3>"; 
		 }?>
		 <h3><a href='index.php'>Log out</a></h3>
		</div>
        </div>
		
	
		 
		 
		 
		 
		 
		 
        <div class="clr"></div>
       <div class="gadget">
          <h2 class="star"><span>Artists</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artistsql = mysql_query("SELECT mem_id, mem_lname, mem_fname, mem_status from members where mem_status='Artist'");
				
				while($artist_nav = mysql_fetch_object($artistsql) ):		
		
				?>
		
					<li><a href="artistgallery.php?artistid=<?php echo $artist_nav->mem_id;?>"><?php echo $artist_nav->mem_fname;?>&nbsp;<?php echo $artist_nav->mem_lname;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
	</div>
        </div>
		
		
		
		
		<div class="gadget">
          <h2 class="star"><span>Articles and Blogs	</span></h2>
          <div class="clr"></div>		
  
		  <div class="account">
		  <ul class="nav_art">
				<?php 
				include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 
				$artsql = mysql_query("SELECT arti_id,arti_title FROM articles order by arti_id desc");
				while($arti_nav = mysql_fetch_object($artsql) ):		
		
				?>
		
					<li><a href="artist_home.php?aid=<?php echo $arti_nav->arti_id;?>"><?php echo $arti_nav->arti_title;?></a></li>
				
				<?php
					endwhile;
				?>
      </ul>
         
				</div>
        </div>
		<?php include "change_password_sidebar.php"?>	
		
		
       
      </div>
      <div class="clr"></div>
    </div>
  </div>
  
  
 <?PHP include "includes/footer.php";?>
</div>
</body>
</html>
