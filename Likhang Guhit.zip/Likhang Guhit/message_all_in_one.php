<h2>Message</h2>
		<hr>
	 
	  <button class="btn-message"> New Message </button>
	   <?PHP
		
			if(isset($_POST["ipadala_na"])){
				$mess_username=$_POST["papadalhan"];
				$mess_body=$_POST["liham"];
				$akin_id=$_SESSION["id"];
				$getinfo = "select mem_id from members where mem_username='$mess_username'";
				$query = mysql_query($getinfo);
				$row = mysql_fetch_array($query);
				if ($row)
				{
				$nakaw1 = $row['mem_id'];
				$messsql = "insert into message (rec_mem_id, send_mem_id, mess_content,mess_status) 
				values('$nakaw1', '$akin_id', '$mess_body','Unread')";
				$res = mysqli_query($con, $messsql);
				if($res)
				{
				echo "Message Sent";
				}
				}
				else
				{
				echo "Username '$mess_username' doesnt exist";
				}
				
			}
		
		
				?>	
	  <script> $('document').ready(function(){
	$('.popup').hide();
	$('.btn-message').click(function(){
		$('.popup').slideDown(300);
	}, function(){
		$('.popup').slideUp(300);
	});
	
	});

	</script>
	 
	  		<div style="border-style:solid;background-color:grey;"class="popup">
		<div class="inside">
		
		<form action="" method="post">
		Username:<br>
		<input type="text" name="papadalhan" placeholder="username" required><br><br>
		Message:<br>
		<textarea name="liham" rows="6" cols="80"></textarea><br><br>
		<div class="btnsend"><input type="submit" name="ipadala_na" value="SEND	"></div>
		
		</form>
		</div>
		</div>
	  <table align="left" >
							<thead>
									<tr><th></th>
									  <th width="60px">Sender</th><br>
									  <th>Content</th>
									  <th>Date</th> <th></th> <th></th>
									  <th> </th>
									</tr>
								  </thead>
		<?php 
		$session_id=$_SESSION["id"];
		$result = mysql_query("select message.*,members.mem_username from message join members on message.send_mem_id=members.mem_id where rec_mem_id=$session_id order by mess_id desc");
		while($datamess = mysql_fetch_object($result) ):
		?>
	<tbody>
		<tr>
		<td><?php $var=$datamess->mess_id ;
		
	$sql_check = mysql_query("Select mess_status from message where mess_id=$var ");
	$checking=mysql_fetch_object($sql_check);
	$checkingresult=$checking->mess_status;
	if($checkingresult=="Unread")
		{	
		echo "<img src='images/close.jpg' width='20' height='20'>";
		}
		else
		echo "<img src='images/open.jpg' width='20' height='20'>";
		?></td><br><td>&nbsp;&nbsp;<?php echo $datamess->mem_username ?></td><br>
		<td><?php echo $datamess->mess_content?></td><br>
		<td><?php echo $datamess->mess_date?></td><br>
		<td><a href="message_reply_admin.php?repz=<?php echo $datamess->mess_id?>">Reply</a></td>
		<td><a href="delete_messagebyID.php?bura_mensahe=<?php echo $datamess->mess_id?>"> Delete Message </a></td>
		</tr>
	
		<?Php
		endwhile;
		?>
		</tbody>
			</table>
		
	<!----------------reply message dialog-------------->
	
	<!----
	<script type="text/javascript">
    $(function () {
        $(".reply").dialog({
            modal: true,
            autoOpen: false,
            title: "Message",
            width: 530,
            height: 350
        });
        $(".btn-reply").click(function () {
            $('.reply').dialog('open');
        });
    });
</script>
-->
	
		
		
		
		
		
		
		
		
		
		
		<!---
		
		
<script src="http://ajax.aspnetcdn.com/ajax/jquery.ui/1.8.9/jquery-ui.js" type="text/javascript"></script>

		
	 <script type="text/javascript">
    $(function () {
        $(".popup").dialog({
            modal: true,
            autoOpen: false,
            title: "Message",
            width: 530,
            height: 350
        });
        $(".btn-message").click(function () {
            $('.popup').dialog('open');
        });
    });
</script>-->
		</div>