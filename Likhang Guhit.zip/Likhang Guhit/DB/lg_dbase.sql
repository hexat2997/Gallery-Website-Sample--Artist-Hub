-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 02, 2017 at 01:48 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lg_dbase`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `arti_id` int(11) NOT NULL AUTO_INCREMENT,
  `arti_title` varchar(50) NOT NULL,
  `arti_imagepath` varchar(200) NOT NULL,
  `arti_parag` text NOT NULL,
  `arti_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mem_id` int(11) NOT NULL,
  PRIMARY KEY (`arti_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`arti_id`, `arti_title`, `arti_imagepath`, `arti_parag`, `arti_date`, `mem_id`) VALUES
(33, 'Happy? Sad?', 'uploads/10999007_946228078761887_4420627932671788641_n.jpg', 'Happy? Sad? Namangha ka ba? Tara na sumali sa Guhit Pinas Mindoro. ', '2016-10-06 08:54:20', 13),
(34, 'Kerby Rosanes: The Doodler', 'uploads/rg.jpg', 'Philippines-based illustrator Kerby Rosanes works mainly with ordinary black pens to magically illustrate his "doodle" world. Most of his works are characterized by whimsical lines, patterns, characters and little elements that are spontaneously combined to create massive compositions depicting his everyday experiences or anything that inspires him. He recently left his job as a graphic designer in a local company to finally pursue his passion: creating more art for personal projects and for various clients and collaborating with other artists and design agencies around the world.', '2016-10-06 09:16:29', 13),
(35, 'Mahiwagang Mata', 'uploads/s.jpg', 'Mayroong ibat-ibang uri ng mata. Alin ang sayo? Kamangha-mangha ang mga mata nila. Ang ku-cute nila.. Masaya sila sa buhay nila. Jejejemon ako.', '2016-10-06 09:18:49', 13),
(32, '6th Guhit Pinas Mee Up', 'uploads/12278774_416472005210200_9112750231645156719_n-1.jpg', 'The said Meet up have their guest, Pres. Rodman Papros-The President of Guhit Pinas. It was occured last December 06, 2015 at Bulusan Park, Bulusan Calapan City. It is the Meet up of different artist from Oriental Mindoro. Tutorials, Meeting the President, On the Spot Drawing, Collab Awarding and Art trade are the most exciting event in the Meet up. The president was looking forward for different meet up in the future', '2016-10-06 03:44:06', 13);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `gal_id` int(11) NOT NULL AUTO_INCREMENT,
  `gal_title` varchar(20) NOT NULL,
  `gal_medium` varchar(50) NOT NULL,
  `gal_img` varchar(200) NOT NULL,
  `mem_id` int(11) NOT NULL,
  PRIMARY KEY (`gal_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gal_id`, `gal_title`, `gal_medium`, `gal_img`, `mem_id`) VALUES
(37, 'Jordan', 'Colored Pencil', 'gallery/_20160511_144417.JPG', 22),
(36, 'Curry', 'Colored Pencil', 'gallery/_20160507_143427.JPG', 22),
(38, 'Kobe', 'Colored Pencil', 'gallery/13537629_1202380716479954_312236302684765346_n.jpg', 23),
(39, 'Happy Sad', 'Colored Pencil', 'gallery/_20160531_232207.JPG', 23),
(40, 'Eye', 'Colored Pencil', 'gallery/5.jpg', 23),
(41, 'Spiderman', 'Water Color', 'gallery/13139236_1024191697629338_1335973330774250479_n.jpg', 30),
(42, 'Sibol Art Challenge', 'Mixed Media', 'gallery/14207776_1310786105606219_3167156531409069897_o.jpg', 31),
(50, 'Emma Watson', 'Pilot Ballpen', 'gallery/13669511_730230703786911_6930275946729746394_o.jpg', 32),
(49, 'Curry 30', 'Multi-Colored Pen', 'gallery/13641042_730230037120311_7213694394272269577_o.jpg', 32);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `mem_id` int(11) NOT NULL AUTO_INCREMENT,
  `mem_fname` varchar(50) NOT NULL,
  `mem_lname` varchar(50) NOT NULL,
  `mem_username` varchar(50) NOT NULL,
  `mem_password` varchar(70) NOT NULL,
  `mem_contact` varchar(17) NOT NULL,
  `mem_address` varchar(50) NOT NULL,
  `mem_status` varchar(50) NOT NULL,
  PRIMARY KEY (`mem_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`mem_id`, `mem_fname`, `mem_lname`, `mem_username`, `mem_password`, `mem_contact`, `mem_address`, `mem_status`) VALUES
(24, 'Christian Paul', 'Cunanan', 'sipek', '632e99e966ab48a596914d4b3cc0198e7fb7a663', '09306324603', 'Masipit', 'Member'),
(22, 'Troy', 'De Asis', 'troy', '1cb5bd5a9e45420321f44c72da5d90d7f0432ffb', '09306324603', 'Panikian, Naujan', 'Artist'),
(13, 'Emerson', 'Caisip', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '09128470357', 'Malamig, Calapan City', 'Admin'),
(23, 'Glenn', 'Gutierrez', 'glenn', '08e39766bc8162cb5690eb45d82f1c75fcded5c4', '09306324603', 'Masipit', 'Artist'),
(32, 'Royel', 'Aceveda', 'Royel', '2cf89841afff562fe77ad8a5ba8755e060bc68ea', '09345678765', 'Baco', 'Artist'),
(31, 'Famela', 'Telmo', 'fam', '3fda8cf018b542f405493d78ea980b2545014644', '09345678765', 'Bayanan', 'Artist'),
(30, 'Erris', 'Alumisin', 'Manong', 'e259bcada20c80687497667573d51efe4b59d648', '09123456544', 'Masi', 'Artist');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `mess_id` int(11) NOT NULL AUTO_INCREMENT,
  `rec_mem_id` int(11) NOT NULL,
  `send_mem_id` int(11) NOT NULL,
  `mess_content` text NOT NULL,
  `mess_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mess_status` varchar(50) NOT NULL,
  PRIMARY KEY (`mess_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=188 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`mess_id`, `rec_mem_id`, `send_mem_id`, `mess_content`, `mess_date`, `mess_status`) VALUES
(116, 30, 13, 'isa pa', '2016-10-06 01:35:06', 'Read'),
(130, 13, 30, 'isa pa', '2016-10-06 01:32:33', 'Read'),
(127, 24, 13, 'nice', '2016-10-06 01:51:17', 'Read'),
(145, 32, 13, 'Lets try messaging', '2016-10-17 22:49:07', 'Read'),
(166, 22, 13, 'troy.', '2016-10-17 22:16:33', 'Read'),
(168, 22, 13, 'hahah.,musta ka na', '2016-10-17 22:17:45', 'Read'),
(170, 22, 13, 'ay ok na ang web?', '2016-10-17 22:18:11', 'Read'),
(174, 22, 13, 'ok naba un?', '2016-10-17 22:39:48', 'Read'),
(175, 22, 13, 'isa pa', '2016-10-17 22:38:57', 'Read'),
(179, 13, 22, 'ok', '2016-10-18 09:19:37', 'Read'),
(182, 22, 24, 'padrawing po', '2016-10-18 09:57:16', 'Read'),
(183, 24, 22, 'wait lang busy pa', '2016-10-18 09:57:50', 'Read'),
(184, 22, 13, 'talga?', '2016-12-17 09:21:29', 'Unread'),
(185, 24, 30, 'musta?', '2017-01-29 19:54:47', 'Read'),
(186, 30, 24, 'oks.', '2017-01-29 19:55:14', 'Read'),
(187, 24, 30, 'ahh', '2017-01-29 19:55:21', 'Unread'),
(181, 13, 22, 'ang haba', '2016-12-17 09:21:22', 'Read');

-- --------------------------------------------------------

--
-- Table structure for table `notif_message`
--

CREATE TABLE IF NOT EXISTS `notif_message` (
  `notif_mess_id` int(11) NOT NULL AUTO_INCREMENT,
  `mess_id` int(11) NOT NULL,
  `mess_status` varchar(50) NOT NULL,
  PRIMARY KEY (`notif_mess_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `notif_message`
--


-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `slider_id` int(11) NOT NULL AUTO_INCREMENT,
  `slider_img` varchar(200) NOT NULL,
  PRIMARY KEY (`slider_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slider_id`, `slider_img`) VALUES
(80, 'uploads/4.jpg'),
(78, 'uploads/slide4.jpg'),
(79, 'uploads/3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comment`
--

CREATE TABLE IF NOT EXISTS `tbl_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `arti_id` int(11) NOT NULL,
  `mem_id` int(11) NOT NULL,
  `comment_body` varchar(200) NOT NULL,
  `comment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_comment`
--

INSERT INTO `tbl_comment` (`comment_id`, `arti_id`, `mem_id`, `comment_body`, `comment_date`) VALUES
(15, 31, 24, 'heheh', '2016-10-06 01:51:36'),
(3, 0, 23, 'Awesome :)', '2016-10-03 05:09:02'),
(5, 13, 13, 'pasama nmn dre', '2016-10-03 07:58:05'),
(6, 13, 13, 'maica', '2016-10-03 08:14:40'),
(7, 13, 25, 'fafadsfda', '2016-10-03 19:39:55'),
(14, 23, 13, 'dfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fgbfgh fhbgfdfgdfbfh fg', '2016-10-04 13:59:44'),
(16, 33, 32, 'Gandan nmn!!!', '2016-10-06 09:05:22'),
(17, 34, 13, 'kilala ko nga yan ii.,magaling yan..', '2016-10-06 09:17:06'),
(18, 35, 30, 'BSIT', '2016-10-10 11:51:39'),
(19, 34, 13, 'dfs', '2016-10-10 14:14:02'),
(20, 35, 24, 'hellow pows', '2016-10-18 09:36:19');
