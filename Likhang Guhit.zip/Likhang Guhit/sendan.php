<?PHP
		
			if(isset($_POST["3"])){
				$mess_username=$_POST["1"];
				$mess_body=$_POST["2"];
				$akin_id=$_SESSION["id"];
				$getinfo = "select mem_id from members where mem_username='$mess_username'";
				$query = mysql_query($getinfo);
				$row = mysql_fetch_array($query);
				$nakaw1 = $row['mem_id'];
				$messsql = "insert into message (rec_mem_id, send_mem_id, mess_content) 
				values('$nakaw1', '$akin_id', '$mess_body')";
				$res = mysqli_query($con, $messsql);
				if($res)
				{
				header("location:message.php"); 
				echo "Message Sent";
				}
				
			}
		
		
				?>


