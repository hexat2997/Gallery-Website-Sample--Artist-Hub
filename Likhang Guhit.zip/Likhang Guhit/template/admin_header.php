<div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
          <li class="active" ><a href="index.php"><span>Home Page</span></a></li>
          <li><a href="blog.html"><span>Blog</span></a></li>
          <li><a href="contact.html"><span>Contact Us</span></a></li>
		     <li><a href="admin_pref.php"><span>Admin Preferences</span></a></li>
        </ul>	
      </div>
      <div class="clr"></div>
	   <div class="slider">
	   <?php
	   $sql2 = "SELECT * FROM slider";
$query2 = mysqli_query($con, $sql2);
	if($fetch = mysqli_fetch_array($query2))
	{
	
			$slide_id = $fetch["slider_id"];
			$slide_image = $fetch["slider_img"];
			
	
	}
	?>
	
    <div id="coin-slider"><a href="# "><img src=<?php echo $slide_image; ?>  width="960" height="333" alt="" /></a> <a href="#"><img src="images/slide5.jpg" width="960" height="333" alt="" /></a> <a href="#"><img src="images/slide6.jpg" width="960" height="333" alt="" /></a>
	
	</div>

		<div class="clr"></div>
      </div>
	 
      <div class="clr"></div>
     
  </div>
	</div>