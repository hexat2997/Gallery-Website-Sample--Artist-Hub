<div class="header">
    <div class="header_resize">
      <div class="logo">
       <!--- <h1><a href="index.html">Likhang<span>Guhit</span> <small>Company Slogan Here</small></a></h1> -->
	   <a href="#"><img src="images/logo1.png"></img></a>
      </div>
      <div class="menu_nav">
        <ul>
          <li class="active" ><a href="index.php"><span>Home Page</span></a></li>
          
		  <li><a href="support.html"><span>Support</span></a></li>
          <li><a href="about.html"><span>About Us</span></a></li>
          <li><a href="blog.html"><span>Blog</span></a></li>
          <li><a href="contact.html"><span>Contact Us</span></a></li>
        </ul>
      </div>
      <div class="clr"></div>
	   <div class="slider">
        <div id="coin-slider"><a href="#"><img src="images/slide4.jpg" width="960" height="333" alt="" /></a> <a href="#"><img src="images/slide5.jpg" width="960" height="333" alt="" /></a> <a href="#"><img src="images/slide6.jpg" width="960" height="333" alt="" /></a>
		</div>

		<div class="clr"></div>
      </div>
	 
      <div class="clr"></div>
     
  </div>
    
	
	</div>