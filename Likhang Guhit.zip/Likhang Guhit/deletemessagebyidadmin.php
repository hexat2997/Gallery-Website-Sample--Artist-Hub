<?php 
include "includes/new_con.php"; /** calling of connection.php that has the connection code **/ 

$id = $_GET['bura_mensahe']; /** get the student ID ***/

mysql_query("DELETE FROM message where mess_id = '$id'"); /** execute the sql delete code **/

header("Location: message.php"); /** redirect to delete.php **/

?>
